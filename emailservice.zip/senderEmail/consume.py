import os
import sys
import json
import time
import smtplib
from pathlib import Path

import pika # type: ignore
import django
from django.core.mail import send_mail
import environ # type: ignore
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.core.mail import EmailMultiAlternatives




BASE_DIR = Path(__file__).resolve().parent.parent 
if str(BASE_DIR) not in sys.path:
    sys.path.append(str(BASE_DIR))

env = environ.Env()
environ.Env.read_env()


os.environ.setdefault("DJANGO_SETTINGS_MODULE", "emailservice.settings")
django.setup()

# --- RabbitMQ / queue config
RABBITMQ_URL            = env("RABBITMQ_URL")
EXCHANGE_NAME           = env("EXCHANGE_NAME")
EMAIL_QUEUE             = env("EMAIL_QUEUE")
EMAIL_ROUTING_KEY       = env("EMAIL_ROUTING_KEY")
FAILED_QUEUE            = env("FAILED_QUEUE")
FAILED_ROUTING_KEY      = env("FAILED_ROUTING_KEY")
EXCHANGE_TYPE           = env("EXCHANGE_TYPE")



MAX_RETRIES = 3  # max send attempts per notification

def channel_publisher(channel, exchanger_name, routing_key, payload):

    channel.basic_publish(
        exchange=exchanger_name,
        routing_key=routing_key,
        body=json.dumps(payload),
        properties=pika.BasicProperties(
            content_type="application/json",
            delivery_mode=2,  # persistent
        ),
    )

def get_connection():
    """Create a blocking connection to RabbitMQ."""

    # credentials = pika.PlainCredentials("user", "password")
    params = pika.URLParameters(RABBITMQ_URL)

    # credentials = pika.PlainCredentials("nqdlzpvs", "Tj5-G0boaSyrS1nZFM4aL9ElaiSeKTmW")

    # connection_params = pika.ConnectionParameters(
    #     host="chameleon-01.lmq.cloudamqp.com",
    #     port=5672,
    #     virtual_host="nqdlzpvs",
    #     credentials=credentials
    # )
    # value = pika.BlockingConnection(connection_params)
    # print(value)
    # return value
    return pika.BlockingConnection(params)
    # return pika.BlockingConnection(params)




def channel_connector(connection, worker_load_per_time):
    channel = connection.channel()

    # Ensure exchange & queues exist (idempotent)
    channel.exchange_declare(
        exchange=EXCHANGE_NAME,
        exchange_type=EXCHANGE_TYPE,
        durable=True,
    )

    channel.queue_declare(queue=EMAIL_QUEUE, durable=True)
    channel.queue_declare(queue=FAILED_QUEUE, durable=True)

    channel.queue_bind(queue=EMAIL_QUEUE, exchange=EXCHANGE_NAME, routing_key=EMAIL_ROUTING_KEY)
    channel.queue_bind(queue=FAILED_QUEUE, exchange=EXCHANGE_NAME, routing_key=FAILED_ROUTING_KEY)

    # Fair dispatch: one unacked message per worker at a time
    channel.basic_qos(prefetch_count=worker_load_per_time)

    return channel

def send_email(payload: dict):
    """
    Actually send the email using Django's email backend.
    Expects:
      payload["to_email"], ["subject"], ["body"] (optional ["html_body"])
    """
    to_email = payload["to_email"]
    subject = payload.get("subject") or ""
    body = payload.get("body") or ""
    # html_body = payload.get("html_body")

    html_message = render_to_string('senderEmail/welcome.html', {
        'user_email': to_email,
        'site_name': 'HNG 13 Stage 4 Group 37'
    })
    html_body = strip_tags(html_message)

    send_mail(
        subject=subject,
        message=body,
        from_email=os.getenv("DEFAULT_FROM_EMAIL"),
        recipient_list= [to_email],
        fail_silently=False, 
        html_message=html_message
    )


def publish_failed(channel, payload: dict, reason: str):
    """
    Send permanently failed notifications to failed.queue.
    Gateway (or whoever) can consume this and update status.
    """
    failed_payload = {
        **payload,
        "status": "failed",
        "reason": reason,
    }

    channel_publisher(channel, EXCHANGE_NAME, FAILED_ROUTING_KEY, failed_payload)
    print(f"💀 Sent to failed.queue: {failed_payload}")


def republish_with_retry(channel, payload: dict, attempt: int):
    """
    Republish message back to email queue with incremented attempt
    and exponential backoff delay.

    Note:
      This uses time.sleep() to keep it simple.
      In a more advanced setup, you'd use delayed queues / TTL instead.
    """
    next_attempt = attempt + 1
    delay = 2 ** next_attempt  # 2, 4, 8, ... seconds

    print(f"⏱ Retry attempt {next_attempt} in {delay}s for notification_id={payload.get('notification_id')}")
    time.sleep(delay)

    retry_payload = {
        **payload,
        "attempt": next_attempt,
    }

    
    channel_publisher(channel, EXCHANGE_NAME, EMAIL_ROUTING_KEY, retry_payload)
    print(f"🔁 Requeued for retry: {payload}")



# def send_email_with_id(to_email: list[str], subject: str, html_body: str, text_body: str, notification_id: str):
def send_email_with_id(payload: dict):
    """
    Send an email with an X-Notification-ID header so you can match it later in the webhook.
    """
    notification_id = payload["notification_id"]
    to_email = payload["to_email"]
    subject = payload.get("subject") or ""
    body = payload.get("body") or ""

    html_message = render_to_string('senderEmail/welcome.html', {
        'user_email': to_email,
        'site_name': 'HNG 13 Stage 4 Group 37'
    })
    html_body = strip_tags(html_message)

    headers = {
        # Mailtrap's SMTP custom-variables header (JSON, <= 1000 bytes)
        "X-MT-Custom-Variables": json.dumps({"notification_id": notification_id}),
    }

    email = EmailMultiAlternatives(
        subject=subject,
        body=body,
        from_email=os.getenv("DEFAULT_FROM_EMAIL"),
        to=[to_email],
        
        headers=headers
    )
    # HTML alternative
    # email.content_subtype = "html"
    email.attach_alternative(html_body, "text/html")

    

    # Optional: also override Message-ID if you want deterministic trace
    # from email.utils import make_msgid
    # email.message().add_header("Message-ID", make_msgid(notification_id))

    email.send(fail_silently=False)
    print(f"✅ Sent email with X-Notification-ID={notification_id}")




def callback(channel, method, properties, body):
    """
    Main worker callback:
      - parses message
      - sends email
      - handles retries
      - pushes to failed.queue on final failure
    """
    try:
        payload = json.loads(body.decode("utf-8"))
    except Exception as e:
        raw_body = body.decode("utf-8", errors="replace")
        print("❌ Invalid JSON, discarding message")

        failed_pay_load = {
            "raw_body" : raw_body
        }

        publish_failed(channel, failed_pay_load, f"invalid_json: {e}")
        channel.basic_ack(delivery_tag=method.delivery_tag)
        return
    
    if not isinstance(payload, dict):
        failed_pay_load = {
            "raw_body" : body.decode("utf-8", errors="replace")
        }

        publish_failed(channel, failed_pay_load, f"Payload is not a valid JSON object")
        channel.basic_ack(delivery_tag=method.delivery_tag)
        return
    

    notification_id = payload.get("notification_id", None)
    attempt = int(payload.get("attempt", 0))

    print(f"\n📨 Received message: notification_id={notification_id}, attempt={attempt}, payload={payload}")

    try:

        # Try sending email
        # send_email(payload)
        send_email_with_id(payload)
        print(f"✅ Email sent for notification_id={notification_id}")

        # Here you could also publish a "sent" status event back to gateway if required

        # Ack: message has been fully handled
        channel.basic_ack(delivery_tag=method.delivery_tag)

    except (smtplib.SMTPException, OSError) as exc:
        # Transient / network / SMTP failure → retry or fail
        print(f"⚠️ Error sending email for notification_id={notification_id}: {exc}")

        if attempt + 1 < MAX_RETRIES:
            # Schedule retry by republishing with incremented attempt
            republish_with_retry(channel, payload, attempt)
            # Ack the current message (we've moved responsibility to the new one)
            channel.basic_ack(delivery_tag=method.delivery_tag)
        else:
            # Max retries reached → send to failed.queue
            print(f"💣 Max retries reached for notification_id={notification_id}, moving to failed.queue")
            publish_failed(channel, payload, str(exc))
            channel.basic_ack(delivery_tag=method.delivery_tag)

    except Exception as exc:
        # Unknown / fatal error → send straight to failed.queue
        print(f"🔥 Unexpected error for notification_id={notification_id}: {exc}")
        publish_failed(channel, payload, f"unexpected_error: {exc}")
        channel.basic_ack(delivery_tag=method.delivery_tag)


def main():
    connection = get_connection()
    channel = channel_connector(connection, 1)

    channel.basic_consume(queue=EMAIL_QUEUE, on_message_callback=callback)

    print("🐇 Email worker listening on email.queue (Ctrl+C to stop)")
    try:
        channel.start_consuming()
    except KeyboardInterrupt:
        print("\n👋 Stopping worker...")
        channel.stop_consuming()
    finally:
        connection.close()


if __name__ == "__main__":
    main()
