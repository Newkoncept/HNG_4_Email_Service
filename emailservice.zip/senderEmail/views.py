from django.shortcuts import render
from django.http import HttpResponse
from django.core.mail import send_mail
import os
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.views.decorators.csrf import csrf_exempt
import json
from datetime import datetime, timezone
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view(http_method_names=['GET'])
def health_checker(api_view):
    data =  {
        "service": "email",
        "rabbitmq_connected": True,
        "smtp_reachable": True,
        "breaker_state": "off"
    }
    return Response(data, status=200)


def home(request):
    return HttpResponse("Welcome home")


def send_simple_email(to_email: list, subject: str, body: str):

    html_message = render_to_string('senderEmail/welcome.html', {
        'user_email': to_email[0],
        'site_name': 'HNG 13 Stage 4 Group 37'
    })
    plain_message = strip_tags(html_message)

    sendvalue = send_mail(
        subject=subject,
        message=body,
        from_email=os.getenv("DEFAULT_FROM_EMAIL"),
        recipient_list= to_email,
        fail_silently=False, 
        html_message=html_message
    )

    print(f"Completed this email sending process by {datetime.now(timezone.utc)}, {sendvalue}")


def sendEmail(request):
    send_simple_email(
        [os.getenv("CUSTOMER_EMAIL")],
        "Welcome!",
        "Thanks for signing up 🥳"
    )

    return HttpResponse("welcome")



@csrf_exempt
def webHook(request):

    if request.method != "POST":
        return HttpResponse("method_not_allowed", status=405)

    if request.method == "POST":
        payload = json.loads(request.body.decode("utf-8"))

        events = payload.get("events", "")[0]

        if events:
            event = events.get("event")
            notification_id = events.get("custom_variables").get("notification_id")

            if event == "delivery":
                pass #logic to update the DB with current status
            elif event == "bounce":
                pass #logic to update the DB with current status
            elif event == "soft bounce":
                pass #logic to update the DB with current status



        print(f"Completed this webhook process by {datetime.now(timezone.utc)}")

        print("Received payload:", payload)
    
    return HttpResponse("webhook")
    


