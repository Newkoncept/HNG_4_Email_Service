import pika, json

def callback(ch, method, properties, body):
    data = json.loads(body)
    print(" [x] Received:", data)
    # Simulate send logic here
    ch.basic_ack(delivery_tag=method.delivery_tag)

connection = pika.BlockingConnection(pika.ConnectionParameters("localhost"))
channel = connection.channel()

channel.queue_declare(queue="email.queue", durable=True)
channel.basic_qos(prefetch_count=1)
channel.basic_consume(queue="email.queue", on_message_callback=callback)

print(" [*] Waiting for messages in email.queue. To exit press CTRL+C")
channel.start_consuming()


