import pika, json
from uuid import uuid4

def populate():
    connection = pika.BlockingConnection(pika.ConnectionParameters("localhost"))
    channel = connection.channel()

    channel.exchange_declare(exchange="hng_stage_four", exchange_type="direct", durable=True)

    # Send an example email message
    message = {
        "notification_id": str(uuid4()),
        "to_email": "bounce+550+no+such+user+here@inbox.mailtrap.io",
        "subject": "Test Email",
        "body": "This is a mock test email.",
        "attempt": 0
    }
    # message = {"invalid"}
    channel.basic_publish(
        exchange="hng_stage_four",
        routing_key="email",
        body=json.dumps(message),
        # body=message,
        properties=pika.BasicProperties(
            content_type="application/json",
            delivery_mode=2,  # persistent
        )
    )

    print(" [x] Sent mock email message")
    connection.close()


populate()